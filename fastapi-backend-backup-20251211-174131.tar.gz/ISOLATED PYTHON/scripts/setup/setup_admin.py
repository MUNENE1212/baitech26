#!/usr/bin/env python3
"""
Quick script to create admin user for Baitech
"""
import asyncio
from utils.database import db
from utils.security import hash_password

async def setup_admin():
    # Admin credentials
    admin_data = {
        "name": "Baitech Admin",
        "email": "admin@baitech.co.ke",
        "password": hash_password("Wincers#1"),  # Change this password after first login
        "role": "admin"
    }

    # Check if admin exists
    existing = await db.users.find_one({"email": admin_data["email"]})

    if existing:
        print(f"⚠ Admin user already exists: {admin_data['email']}")
        print(f"   Name: {existing.get('name')}")
        print(f"   Role: {existing.get('role')}")

        # Update to ensure admin role
        await db.users.update_one(
            {"email": admin_data["email"]},
            {"$set": {"role": "admin"}}
        )
        print("✓ Ensured admin role is set")
    else:
        # Create new admin
        result = await db.users.insert_one(admin_data)
        print("✓ Admin user created successfully!")
        print(f"  ID: {result.inserted_id}")

    print("\n" + "=" * 60)
    print("ADMIN LOGIN CREDENTIALS")
    print("=" * 60)
    print(f"Email:    {admin_data['email']}")
    print(f"Password: Admin123!")
    print(f"Role:     admin")
    print("\n⚠ IMPORTANT: Change the password after first login!")
    print("\nLogin at: http://localhost:3000/login")
    print("=" * 60)

    # List all admins
    print("\nAll Admin Users:")
    admins = await db.users.find({"role": "admin"}).to_list(100)
    for i, admin in enumerate(admins, 1):
        print(f"  {i}. {admin.get('name')} - {admin.get('email')}")

if __name__ == "__main__":
    print("Setting up Baitech admin user...\n")
    asyncio.run(setup_admin())
