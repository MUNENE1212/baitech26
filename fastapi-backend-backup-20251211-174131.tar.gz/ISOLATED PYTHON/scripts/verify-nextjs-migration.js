#!/usr/bin/env node

/**
 * Verification script to test all Next.js API endpoints
 * Run this after migration to ensure all functionality works without Python backend
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 Verifying Next.js-only migration...\n');

// Test configuration
const tests = {
  // Public endpoints
  public: [
    { method: 'GET', endpoint: '/api/health', description: 'Health check' },
    { method: 'GET', endpoint: '/api/home', description: 'Homepage data' },
    { method: 'GET', endpoint: '/api/products', description: 'Products list' },
    { method: 'GET', endpoint: '/api/products/featured', description: 'Featured products' },
    { method: 'GET', endpoint: '/api/services', description: 'Services list' },
    { method: 'GET', endpoint: '/api/settings', description: 'Public settings' }
  ],

  // Admin endpoints (will test with mock token)
  admin: [
    { method: 'GET', endpoint: '/api/admin/dashboard', description: 'Admin dashboard' },
    { method: 'GET', endpoint: '/api/admin/stats', description: 'Admin statistics' },
    { method: 'GET', endpoint: '/api/users', description: 'Users list' },
    { method: 'GET', endpoint: '/api/admin/images', description: 'Images list' },
    { method: 'GET', endpoint: '/api/orders', description: 'Orders list' },
    { method: 'GET', endpoint: '/api/reviews', description: 'Reviews list' },
    { method: 'GET', endpoint: '/api/admin/activity', description: 'Recent activity' }
  ]
};

// Test results
const results = {
  passed: 0,
  failed: 0,
  skipped: 0,
  details: []
};

/**
 * Test an endpoint
 */
async function testEndpoint(test, category) {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
  const url = `${baseUrl}${test.endpoint}`;

  try {
    const options = {
      method: test.method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    // Add mock authorization for admin endpoints
    if (category === 'admin') {
      options.headers['Authorization'] = 'Bearer mock-admin-token-for-testing';
    }

    const response = await fetch(url, options);

    const result = {
      ...test,
      status: response.status,
      success: response.ok,
      category,
      url,
      message: response.ok ? '✅ Success' : `❌ Failed (${response.status})`
    };

    if (response.ok) {
      results.passed++;
    } else {
      results.failed++;
    }

    results.details.push(result);
    console.log(`  ${result.message} - ${test.method} ${test.endpoint}`);

    return result;
  } catch (error) {
    const result = {
      ...test,
      status: 'ERROR',
      success: false,
      category,
      url,
      error: error.message,
      message: `❌ Error: ${error.message}`
    };

    results.failed++;
    results.details.push(result);
    console.log(`  ${result.message} - ${test.method} ${test.endpoint}`);

    return result;
  }
}

/**
 * Check if Next.js server is running
 */
async function checkServerStatus() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

  try {
    const response = await fetch(`${baseUrl}/api/health`);
    if (response.ok) {
      console.log(`✅ Next.js server is running at ${baseUrl}`);
      return true;
    }
  } catch (error) {
    console.log(`\n❌ Next.js server is not running at ${baseUrl}`);
    console.log('Please start the server with: npm run dev\n');
    return false;
  }
}

/**
 * Check if Python backend is still running
 */
async function checkPythonBackend() {
  const pythonUrl = 'http://localhost:8000';

  try {
    const response = await fetch(pythonUrl);
    if (response.ok) {
      console.log(`\n⚠️ Warning: Python backend is still running at ${pythonUrl}`);
      console.log('Consider stopping it after verifying all Next.js endpoints work\n');
      return true;
    }
  } catch (error) {
    console.log('✅ Python backend is not running (good for isolation)\n');
    return false;
  }
}

/**
 * Verify file structure
 */
function verifyFileStructure() {
  console.log('📁 Verifying file structure...\n');

  const requiredFiles = [
    'lib/api/client-nextjs-only.ts',
    'app/api/home/route.ts',
    'app/api/products/route.ts',
    'app/api/services/route.ts',
    'app/admin/layout.tsx',
    'app/admin/page.tsx'
  ];

  const optionalFiles = [
    'app/api/auth/route.ts',
    'app/api/orders/route.ts',
    'app/api/users/route.ts',
    'app/api/admin/dashboard/route.ts',
    'app/api/admin/upload/route.ts',
    'app/api/reviews/route.ts',
    'app/api/settings/route.ts'
  ];

  console.log('Required files:');
  requiredFiles.forEach(file => {
    if (fs.existsSync(path.join(process.cwd(), file))) {
      console.log(`  ✅ ${file}`);
    } else {
      console.log(`  ❌ Missing: ${file}`);
      results.failed++;
    }
  });

  console.log('\nOptional files (missing ones may need implementation):');
  optionalFiles.forEach(file => {
    if (fs.existsSync(path.join(process.cwd(), file))) {
      console.log(`  ✅ ${file}`);
    } else {
      console.log(`  ⚠️ Not implemented: ${file}`);
      results.skipped++;
    }
  });

  console.log('');
}

/**
 * Check environment configuration
 */
function checkEnvironment() {
  console.log('⚙️ Checking environment configuration...\n');

  const envFile = path.join(process.cwd(), '.env.local');

  if (!fs.existsSync(envFile)) {
    console.log('⚠️ .env.local file not found');
    return;
  }

  const content = fs.readFileSync(envFile, 'utf8');

  // Check for Next.js forced mode
  if (content.includes('NEXT_PUBLIC_FORCE_NEXTJS=true')) {
    console.log('✅ Next.js mode is forced');
  } else {
    console.log('⚠️ NEXT_PUBLIC_FORCE_NEXTJS not set to true');
  }

  // Check for Python backend references
  if (content.includes('localhost:8000') || content.includes('NEXT_PUBLIC_LEGACY_API_URL')) {
    console.log('⚠️ Python backend references still exist in .env.local');
  } else {
    console.log('✅ No Python backend references in .env.local');
  }

  // Check for required variables
  const requiredVars = ['MONGODB_URI', 'JWT_SECRET'];
  requiredVars.forEach(variable => {
    if (content.includes(`${variable}=`) && !content.includes(`${variable}=your-`)) {
      console.log(`✅ ${variable} is configured`);
    } else {
      console.log(`⚠️ ${variable} needs configuration`);
    }
  });

  console.log('');
}

/**
 * Generate test report
 */
function generateReport() {
  const report = `# Next.js Migration Verification Report

Generated: ${new Date().toISOString()}

## Test Summary

- **Total Tests**: ${results.passed + results.failed + results.skipped}
- **Passed**: ${results.passed} ✅
- **Failed**: ${results.failed} ❌
- **Skipped**: ${results.skipped} ⚠️

## Public API Endpoints

${results.details
  .filter(r => r.category === 'public')
  .map(r => `- ${r.success ? '✅' : '❌'} ${r.method} ${r.endpoint}: ${r.error || r.message}`)
  .join('\n')}

## Admin API Endpoints

${results.details
  .filter(r => r.category === 'admin')
  .map(r => `- ${r.success ? '✅' : '❌'} ${r.method} ${r.endpoint}: ${r.error || r.message}`)
  .join('\n')}

## Recommendations

${results.failed > 0 ? `
### Failed Endpoints
Failed endpoints need to be implemented before stopping the Python backend. Refer to the migration plan for implementation details.

` : ''}

### Next Steps

1. **If all tests passed**:
   - Stop the Python FastAPI server
   - Remove Python virtual environment
   - Update deployment configuration

2. **If some tests failed**:
   - Implement missing API routes in Next.js
   - Run this verification script again
   - Keep Python backend running for missing endpoints

3. **For production deployment**:
   - Ensure all endpoints are implemented and tested
   - Set up proper error monitoring
   - Configure backup and recovery procedures

## Migration Completion Checklist

- [ ] All public API endpoints work (${results.details.filter(r => r.category === 'public' && r.success).length}/${results.details.filter(r => r.category === 'public').length})
- [ ] All admin API endpoints work (${results.details.filter(r => r.category === 'admin' && r.success).length}/${results.details.filter(r => r.category === 'admin').length})
- [ ] Admin login and authentication works
- [ ] Product management functions
- [ ] Image uploads work
- [ ] Order processing works
- [ ] User management works
- [ ] No Python backend dependencies in frontend
- [ ] Environment configuration updated
- [ ] Production deployment ready

---
${results.failed === 0 ? '🎉 Migration Complete!' : '⚠️ Migration Incomplete - More Work Needed'}
`;

  fs.writeFileSync(
    path.join(process.cwd(), 'NEXTJS_MIGRATION_VERIFICATION_REPORT.md'),
    report
  );

  console.log('📋 Detailed report generated: NEXTJS_MIGRATION_VERIFICATION_REPORT.md');
}

/**
 * Main execution
 */
async function main() {
  // Check prerequisites
  const serverRunning = await checkServerStatus();
  if (!serverRunning) {
    process.exit(1);
  }

  await checkPythonBackend();

  // Verify structure and configuration
  verifyFileStructure();
  checkEnvironment();

  // Run API tests
  console.log('🧪 Testing API endpoints...\n');

  console.log('Public endpoints:');
  for (const test of tests.public) {
    await testEndpoint(test, 'public');
  }

  console.log('\nAdmin endpoints (with mock token):');
  for (const test of tests.admin) {
    await testEndpoint(test, 'admin');
  }

  // Print summary
  console.log('\n📊 Test Summary:');
  console.log(`  Passed: ${results.passed} ✅`);
  console.log(`  Failed: ${results.failed} ❌`);
  console.log(`  Skipped: ${results.skipped} ⚠️`);

  // Generate report
  generateReport();

  // Final message
  if (results.failed === 0) {
    console.log('\n🎉 All endpoints working! Ready to isolate Python backend.');
    console.log('\nFinal steps:');
    console.log('1. Stop Python FastAPI server');
    console.log('2. Remove Python virtual environment');
    console.log('3. Update deployment configuration');
    console.log('4. Monitor production after deployment');
  } else {
    console.log('\n⚠️ Some endpoints are missing. Complete implementation before isolating Python backend.');
    console.log('\nSee NEXTJS_MIGRATION_VERIFICATION_REPORT.md for details.');
  }
}

// Check for required dependencies
try {
  const { glob } = require('glob');
} catch (error) {
  console.error('❌ Required dependency "glob" not found. Please install it with:');
  console.error('   npm install glob');
  process.exit(1);
}

// Run verification
main().catch(console.error);