#!/usr/bin/env node

/**
 * Migration script to transition from hybrid API client to Next.js-only
 * This script helps update imports and configurations for complete Python backend isolation
 */

const fs = require('fs');
const path = require('path');

console.log('🚀 Starting migration to Next.js-only API...\n');

// Configuration
const config = {
  // Files to update imports
  importUpdates: [
    {
      from: 'lib/api/client',
      to: 'lib/api/client-nextjs-only',
      files: ['**/*.{ts,tsx,js,jsx}']
    },
    {
      from: 'lib/api/client-simple',
      to: 'lib/api/client-nextjs-only',
      files: ['**/*.{ts,tsx,js,jsx}']
    }
  ],

  // Environment variables to update
  envUpdates: {
    'NEXT_PUBLIC_FORCE_NEXTJS': 'true',
    'NEXT_PUBLIC_API_URL': 'http://localhost:3000/api',
    // Comment out or remove Python backend reference
    'NEXT_PUBLIC_LEGACY_API_URL': '# http://localhost:8000  # DEPRECATED - Python backend removed'
  },

  // Package scripts to update
  scriptUpdates: {
    'dev': 'next dev',  // Ensure no Python server start
    'build': 'next build',
    'start': 'next start',
    'migrate:complete': 'node scripts/migrate-to-nextjs-only.js'
  }
};

// Track changes
let changes = {
  filesUpdated: 0,
  importsUpdated: 0,
  envUpdated: 0,
  scriptsUpdated: 0
};

/**
 * Update import statements in a file
 */
function updateImports(filePath, updates) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let fileChanged = false;

    updates.forEach(update => {
      const regex = new RegExp(
        `from ['"]${update.from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}['"]`,
        'g'
      );

      if (content.match(regex)) {
        content = content.replace(regex, `from '${update.to}'`);
        changes.importsUpdated++;
        fileChanged = true;
        console.log(`  ✓ Updated import in ${filePath}`);
      }
    });

    if (fileChanged) {
      fs.writeFileSync(filePath, content);
      changes.filesUpdated++;
    }

    return fileChanged;
  } catch (error) {
    console.error(`  ✗ Error updating ${filePath}:`, error.message);
    return false;
  }
}

/**
 * Update environment file
 */
function updateEnvironmentFile() {
  const envFile = path.join(process.cwd(), '.env.local');
  const envExampleFile = path.join(process.cwd(), '.env.local.example');

  try {
    // Update .env.local
    if (fs.existsSync(envFile)) {
      let content = fs.readFileSync(envFile, 'utf8');

      Object.entries(config.envUpdates).forEach(([key, value]) => {
        const regex = new RegExp(`^${key}=.*$`, 'm');

        if (content.match(regex)) {
          content = content.replace(regex, value.startsWith('#')
            ? value
            : `${key}=${value}`);
        } else if (!value.startsWith('#')) {
          content += `\n${key}=${value}`;
        }
      });

      fs.writeFileSync(envFile, content);
      changes.envUpdated++;
      console.log(`  ✓ Updated ${envFile}`);
    }

    // Update .env.local.example
    if (fs.existsSync(envExampleFile)) {
      let content = fs.readFileSync(envExampleFile, 'utf8');

      Object.entries(config.envUpdates).forEach(([key, value]) => {
        const regex = new RegExp(`^${key}=.*$`, 'm');
        const exampleValue = value.startsWith('#')
          ? value
          : value.replace('localhost', 'your-domain.com');

        if (content.match(regex)) {
          content = content.replace(regex, `${key}=${exampleValue}`);
        } else if (!value.startsWith('#')) {
          content += `\n${key}=${exampleValue}`;
        }
      });

      fs.writeFileSync(envExampleFile, content);
      console.log(`  ✓ Updated ${envExampleFile}`);
    }

  } catch (error) {
    console.error('  ✗ Error updating environment files:', error.message);
  }
}

/**
 * Create migration summary
 */
function createMigrationSummary() {
  const summary = `# Migration Summary - Next.js Only API

## Changes Made

### Files Updated: ${changes.filesUpdated}
- Import statements updated: ${changes.importsUpdated}
- Environment variables updated: ${changes.envUpdated}

### Configuration Changes
1. **API Client**: Switched from hybrid to Next.js-only client
2. **Environment**: Forced Next.js mode, removed Python backend references
3. **Imports**: Updated all client imports to use Next.js-only version

## Next Steps

1. Verify all API endpoints are implemented in Next.js
2. Test all admin functionality
3. Stop Python FastAPI server
4. Remove Python virtual environment
5. Update production deployment configuration

## Rollback

If needed, revert imports back to:
- \`lib/api/client\` for hybrid mode
- \`lib/api/client-simple\` for simple mode

## Verification Checklist

- [ ] Admin login works
- [ ] Product management functions
- [ ] Image uploads work
- [ ] Order processing functions
- [ ] User management works
- [ ] Dashboard statistics display correctly
- [ ] No console errors in browser
- [ ] All API calls return success

---
Generated on: ${new Date().toISOString()}
`;

  fs.writeFileSync(
    path.join(process.cwd(), 'MIGRATION_SUMMARY_NEXTJS_ONLY.md'),
    summary
  );
  console.log('\n📝 Migration summary created: MIGRATION_SUMMARY_NEXTJS_ONLY.md');
}

/**
 * Create a backup of important files
 */
function createBackup() {
  const backupDir = path.join(process.cwd(), 'backup-before-migration');

  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  const filesToBackup = [
    'lib/api/client.ts',
    'lib/api/client-simple.ts',
    '.env.local',
    'package.json'
  ];

  filesToBackup.forEach(file => {
    const sourcePath = path.join(process.cwd(), file);
    const backupPath = path.join(backupDir, file);

    if (fs.existsSync(sourcePath)) {
      fs.copyFileSync(sourcePath, backupPath);
      console.log(`  ✓ Backed up ${file}`);
    }
  });

  console.log(`\n📦 Backup created in: ${backupDir}`);
}

/**
 * Main execution
 */
async function main() {
  console.log('📦 Creating backup before migration...');
  createBackup();

  console.log('\n🔄 Updating import statements...');

  // Find and update files with imports
  const { glob } = require('glob');

  for (const update of config.importUpdates) {
    const files = await glob(update.files, { ignore: ['node_modules/**', '.next/**', 'backup-*/**'] });

    for (const file of files) {
      if (fs.existsSync(file)) {
        updateImports(file, [update]);
      }
    }
  }

  console.log('\n⚙️ Updating environment configuration...');
  updateEnvironmentFile();

  console.log('\n📋 Creating migration summary...');
  createMigrationSummary();

  // Print results
  console.log('\n✅ Migration completed!\n');
  console.log('📊 Statistics:');
  console.log(`  - Files updated: ${changes.filesUpdated}`);
  console.log(`  - Imports updated: ${changes.importsUpdated}`);
  console.log(`  - Environment variables updated: ${changes.envUpdated}`);

  console.log('\n⚠️ Important reminders:');
  console.log('1. Verify all API endpoints are implemented in Next.js');
  console.log('2. Test all admin functionality before stopping Python server');
  console.log('3. Check MIGRATION_SUMMARY_NEXTJS_ONLY.md for detailed next steps');
  console.log('4. Remove Python virtual environment only after confirming everything works');

  console.log('\n🎉 You\'re ready to use Next.js-only API!');
}

// Check if required dependencies are installed
try {
  require('glob');
} catch (error) {
  console.error('❌ Required dependency "glob" not found. Please install it with:');
  console.error('   npm install glob');
  process.exit(1);
}

// Run the migration
main().catch(console.error);